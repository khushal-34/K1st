document.getElementById("clientForm").addEventListener("submit", async function(e) {
  e.preventDefault();

  const formData = {
    name: this.name.value,
    email: this.email.value,
    message: this.message.value
  };

  await fetch("https://your-backend-api/submit", {
    method: "POST",
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify(formData)
  });

  document.getElementById("clientForm").classList.add("hidden");
  document.getElementById("thanks").classList.remove("hidden");

  setTimeout(() => {
    document.getElementById("thanks").classList.add("hidden");
  }, 10000);
});
