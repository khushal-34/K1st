from openpyxl import Workbook, load_workbook
import os

def save_to_excel(data):
    filename = "clients_locked.xlsx"

    if not os.path.exists(filename):
        wb = Workbook()
        ws = wb.active
        ws.title = "Client Data"
        ws.append(list(data.keys()))
    else:
        wb = load_workbook(filename)
        ws = wb.active

    ws.append(list(data.values()))
    wb.save(filename)
