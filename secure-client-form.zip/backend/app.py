from flask import Flask, request, send_file, jsonify
from excel_handler import save_to_excel
from flask_cors import CORS
import os

app = Flask(__name__)
CORS(app)

HOST_PASSWORD = "supersecret"  # Set this securely

@app.route('/submit', methods=['POST'])
def submit_data():
    data = request.json
    save_to_excel(data)
    return jsonify({"status": "success"})

@app.route('/download', methods=['POST'])
def download_excel():
    password = request.json.get("password")
    if password == HOST_PASSWORD:
        return send_file("clients_locked.xlsx", as_attachment=True)
    else:
        return jsonify({"error": "Unauthorized"}), 401

if __name__ == '__main__':
    app.run()
